<?php
/**
 * Plugin Name:       J-Beauty API Display
 * Plugin URI:        #
 * Description:       Pobiera dane z j-beauty.eu przez REST API i wyświetla je za pomocą shortcode'ów.
 * Version:           1.1.5 - Dodano stronę ustawień API
 * Author:            Sławomir Dukała / Physis sp z o.o.
 * Author URI:        #
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       jbeauty-api-display
 * Domain Path:       /languages
 */

// Zabezpieczenie przed bezpośrednim dostępem
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// =============================================================================
// === SEKCJA USTAWIEŃ WTYCZKI (SETTINGS API) ===
// =============================================================================

/**
 * Dodaje stronę ustawień J-Beauty API Display do menu Ustawienia.
 */
function jbeauty_add_settings_page() {
    add_options_page(
        __( 'J-Beauty API Settings', 'jbeauty-api-display' ), // Tytuł strony (tag <title>)
        __( 'J-Beauty API', 'jbeauty-api-display' ),        // Tekst linku w menu
        'manage_options',                                 // Wymagane uprawnienia do dostępu
        'jbeauty-api-settings',                           // Slug (identyfikator) strony menu
        'jbeauty_render_settings_page'                    // Funkcja renderująca zawartość strony
    );
}
add_action( 'admin_menu', 'jbeauty_add_settings_page' );

/**
 * Renderuje zawartość (HTML) strony ustawień.
 */
function jbeauty_render_settings_page() {
    // Sprawdź uprawnienia użytkownika
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    ?>
    <div class="wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        <form action="options.php" method="post">
            <?php
            // Wyświetla ukryte pola potrzebne do przetworzenia formularza ustawień
            settings_fields( 'jbeauty_api_settings_group' );
            // Wyświetla sekcje i pola zarejestrowane dla tej strony
            do_settings_sections( 'jbeauty-api-settings' );
            // Wyświetla przycisk zapisu
            submit_button( __( 'Save Settings', 'jbeauty-api-display' ) );
            ?>
        </form>
    </div>
    <?php
}

/**
 * Rejestruje ustawienia wtyczki J-Beauty API Display.
 */
function jbeauty_register_settings() {
    // 1. Zarejestruj grupę ustawień
    register_setting(
        'jbeauty_api_settings_group',                 // Nazwa grupy (musi pasować do settings_fields() w formularzu)
        'jbeauty_api_options',                        // Nazwa opcji, w której będą zapisane wszystkie ustawienia (jako tablica)
        'jbeauty_sanitize_options'                    // Funkcja do walidacji/sanityzacji danych przed zapisem
    );

    // 2. Dodaj sekcję do strony ustawień
    add_settings_section(
        'jbeauty_api_connection_section',             // ID sekcji
        __( 'Connection Settings', 'jbeauty-api-display' ), // Tytuł sekcji
        'jbeauty_connection_section_callback',        // Funkcja wyświetlająca opis sekcji
        'jbeauty-api-settings'                        // Slug strony, na której sekcja ma się pojawić
    );

    // 3. Dodaj pole dla adresu URL API
    add_settings_field(
        'jbeauty_api_url',                            // ID pola
        __( 'Physis API Base URL', 'jbeauty-api-display' ),// Etykieta pola
        'jbeauty_api_url_callback',                   // Funkcja renderująca pole input
        'jbeauty-api-settings',                       // Slug strony
        'jbeauty_api_connection_section'              // ID sekcji, do której należy to pole
    );

    // 4. Dodaj pole dla klucza API
    add_settings_field(
        'jbeauty_api_key',                            // ID pola
        __( 'API Key', 'jbeauty-api-display' ),       // Etykieta pola
        'jbeauty_api_key_callback',                   // Funkcja renderująca pole input
        'jbeauty-api-settings',                       // Slug strony
        'jbeauty_api_connection_section'              // ID sekcji
    );
}
add_action( 'admin_init', 'jbeauty_register_settings' );

/**
 * Wyświetla opis dla sekcji ustawień połączenia.
 */
function jbeauty_connection_section_callback() {
    echo '<p>' . __( 'Enter the connection details for the Physis API endpoint.', 'jbeauty-api-display' ) . '</p>';
}

/**
 * Renderuje pole input dla adresu URL API.
 */
function jbeauty_api_url_callback() {
    $options = get_option( 'jbeauty_api_options' );
    $url = isset( $options['api_url'] ) ? esc_url( $options['api_url'] ) : '';
    echo '<input type="url" id="jbeauty_api_url" name="jbeauty_api_options[api_url]" value="' . $url . '" class="regular-text" placeholder="https://your-physis-site.com/wp-json/physis/v1" />';
    echo '<p class="description">' . __( 'Enter the full base URL for the Physis API endpoint (e.g., https://your-physis-site.com/wp-json/physis/v1). No trailing slash.', 'jbeauty-api-display') . '</p>';
}

/**
 * Renderuje pole input dla klucza API.
 */
function jbeauty_api_key_callback() {
    $options = get_option( 'jbeauty_api_options' );
    $key = isset( $options['api_key'] ) ? esc_attr( $options['api_key'] ) : '';
    // Użycie type="password" lekko maskuje klucz
    echo '<input type="password" id="jbeauty_api_key" name="jbeauty_api_options[api_key]" value="' . $key . '" class="regular-text" />';
}

/**
 * Funkcja do sanityzacji opcji przed zapisem.
 */
function jbeauty_sanitize_options( $input ) {
    $sanitized_input = array();
    if ( isset( $input['api_url'] ) ) {
        // Użyj esc_url_raw dla URLi zapisywanych do bazy
        $url = esc_url_raw( trim( $input['api_url'] ), array('http', 'https') );
        // Usuń końcowy slash, jeśli jest
        $sanitized_input['api_url'] = rtrim($url, '/');
    }
    if ( isset( $input['api_key'] ) ) {
        // Klucze API mogą zawierać różne znaki, sanitize_text_field jest bezpiecznym wyborem
        $sanitized_input['api_key'] = sanitize_text_field( trim( $input['api_key'] ) );
    }
    return $sanitized_input;
}


// =============================================================================
// === SHORTCODE [jbeauty_data] - Wyświetlanie pojedynczych pól ===
// =============================================================================
function physis_display_jbeauty_data_shortcode( $atts ) {
    $atts = shortcode_atts( array(
        'cdt_id' => '',
        'field'  => ''
    ), $atts, 'jbeauty_data' );

    $cdt_id_value = sanitize_text_field( $atts['cdt_id'] );
    $field_key    = sanitize_key( $atts['field'] );

    if ( empty($cdt_id_value) || empty($field_key) ) {
        return '';
    }

    // --- Pobierz ustawienia API ---
    $options = get_option( 'jbeauty_api_options' );
    $api_base_url = isset( $options['api_url'] ) ? $options['api_url'] : '';
    $api_key      = isset( $options['api_key'] ) ? $options['api_key'] : '';

    // Sprawdź, czy URL i klucz są skonfigurowane
    if ( empty($api_base_url) ) {
        error_log("[jbeauty_data] API Base URL is not configured in settings!");
        return (current_user_can('manage_options')) ? '<p style="color:red;">' . esc_html__('J-Beauty API URL not configured.', 'jbeauty-api-display') . '</p>' : '';
    }
     if ( empty($api_key) ) {
        error_log("[jbeauty_data] API Key is not configured in settings!");
        return (current_user_can('manage_options')) ? '<p style="color:red;">' . esc_html__('J-Beauty API Key not configured.', 'jbeauty-api-display') . '</p>' : '';
    }
    // --- Koniec pobierania ustawień ---

    // Zbuduj pełny URL endpointu
    $api_url = $api_base_url . '/produkt-by-cdt/' . rawurlencode($cdt_id_value);

    $transient_key = 'jbad_prod_' . md5($cdt_id_value);
    $product_data = get_transient( $transient_key );

    // Jeśli danych nie ma w cache lub cache wygasł
    if ( false === $product_data ) {
        $args = array(
            'headers' => array( 'Authorization' => 'Bearer ' . $api_key ),
            'timeout' => 15
        );
        $response = wp_remote_get( $api_url, $args );
        $product_data = null; // Zresetuj na wypadek błędów

        if ( is_wp_error( $response ) ) {
            error_log("[jbeauty_data] API Fetch Error for CDT ID " . $cdt_id_value . ": " . $response->get_error_message());
            set_transient( $transient_key, 'error_fetch', MINUTE_IN_SECONDS * 5 ); // Cache błędu na 5 min
            return '';
        } else {
            $http_code = wp_remote_retrieve_response_code( $response );
            $body = wp_remote_retrieve_body( $response );

            if ( $http_code === 200 ) {
                $decoded_data = json_decode( $body, true );
                if ( is_array( $decoded_data ) && ! empty( $decoded_data ) ) {
                    $product_data = $decoded_data;
                    // Cache poprawnych danych na 1 godzinę
                    set_transient( $transient_key, $product_data, HOUR_IN_SECONDS );
                } else {
                    error_log("[jbeauty_data] API Decode Error for CDT ID " . $cdt_id_value . ". Body: " . $body);
                    set_transient( $transient_key, 'error_decode', MINUTE_IN_SECONDS * 5 );
                    return '';
                }
            } elseif ( $http_code === 404 ) {
                // Produkt nie znaleziony - cachuj ten stan na dłużej, np. 1 godzinę
                 error_log("[jbeauty_data] API Product Not Found (404) for CDT ID " . $cdt_id_value);
                set_transient( $transient_key, 'not_found', HOUR_IN_SECONDS );
                return '';
            } else {
                // Inne błędy HTTP
                 error_log("[jbeauty_data] API HTTP Error for CDT ID " . $cdt_id_value . ". Code: " . $http_code);
                set_transient( $transient_key, 'error_http_' . $http_code, MINUTE_IN_SECONDS * 5 );
                return '';
            }
        }
    } // Koniec pobierania danych, jeśli nie było w cache

    // Sprawdź, czy dane z cache nie są przypadkiem znacznikiem błędu
    if ( !is_array($product_data) ) {
        // Jeśli w cache jest 'not_found', 'error_fetch' itp., zwróć pusty string
        return '';
    }

    // Przetwarzanie i wyświetlanie danych
    $output_value = '';
    if ( $field_key === 'title' && isset( $product_data['title']['rendered'] ) ) {
        $output_value = $product_data['title']['rendered'];
    } elseif ( $field_key === 'galeria_produktu' && isset( $product_data['galeria_produktu'] ) && is_array($product_data['galeria_produktu']) ) {
        // Shortcode [jbeauty_data] nie jest przeznaczony do wyświetlania galerii, zwróć pusty string lub ID
         return ''; // lub return implode(', ', $product_data['galeria_produktu']); jeśli chcesz ID
    } elseif ( isset( $product_data[ $field_key ] ) ) {
        // Sprawdź, czy wartość nie jest tablicą (np. złożone pole meta)
        if (is_array($product_data[ $field_key ])) {
             error_log("[jbeauty_data] Attempted to display array field '{$field_key}' for CDT ID " . $cdt_id_value);
             $output_value = ''; // Nie wyświetlaj surowej tablicy
        } else {
            $output_value = $product_data[ $field_key ];
        }
    } else {
        // Pole nie istnieje w danych produktu
        return '';
    }

    // Sanityzacja wyjścia w zależności od typu pola
    $escaped_output = '';
    $html_fields = ['_opis_marketingowy', '_sklad', '_sposob_uzycia', '_ostrzezenia', '_tekst_etykieta'];
    $url_fields = ['_materialy_reklamowe_url', '_sklep_hebe_url', '_strona_domowa_url', '_tiktok_url', '_instagram_url', '_facebook_url', 'link'];

    if ( in_array( $field_key, $html_fields, true ) ) {
        $escaped_output = wp_kses_post( $output_value ); // Pozwala na określony HTML
    } elseif ( in_array( $field_key, $url_fields, true ) ) {
        $escaped_output = esc_url( $output_value ); // Tylko bezpieczne URL
    } else {
        // Domyślnie traktuj jako zwykły tekst
        $escaped_output = esc_html( $output_value );
    }

    return $escaped_output;
}
add_shortcode( 'jbeauty_data', 'physis_display_jbeauty_data_shortcode' );


// =============================================================================
// === SHORTCODE [jbeauty_gallery] - Wyświetlanie Galerii ===
// =============================================================================
function physis_display_jbeauty_gallery_shortcode( $atts ) {
    $atts = shortcode_atts( array( 'cdt_id' => '' ), $atts, 'jbeauty_gallery' );
    $cdt_id_value = sanitize_text_field( $atts['cdt_id'] );
    if ( empty($cdt_id_value) ) return '';

    // --- Pobierz ustawienia API ---
    $options = get_option( 'jbeauty_api_options' );
    $api_base_url = isset( $options['api_url'] ) ? $options['api_url'] : '';
    $api_key      = isset( $options['api_key'] ) ? $options['api_key'] : '';

    if ( empty($api_base_url) || empty($api_key) ) {
        error_log("[jbeauty_gallery] API URL or Key is not configured in settings!");
        return (current_user_can('manage_options')) ? '<p style="color:red;">' . esc_html__('J-Beauty API URL or Key not configured.', 'jbeauty-api-display') . '</p>' : '';
    }
    // --- Koniec pobierania ustawień ---

    $transient_key_prod = 'jbad_prod_' . md5($cdt_id_value);
    $product_data = get_transient( $transient_key_prod );

    // Pobierz dane produktu, jeśli nie ma w cache
    if ( false === $product_data ) {
        $api_url = $api_base_url . '/produkt-by-cdt/' . rawurlencode($cdt_id_value);
        $args = array( 'headers' => array( 'Authorization' => 'Bearer ' . $api_key ), 'timeout' => 15 );
        $response = wp_remote_get( $api_url, $args );
        $product_data = null; // Resetuj

        if ( !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200 ) {
            $decoded_data = json_decode( wp_remote_retrieve_body( $response ), true );
            if ( is_array($decoded_data) && !empty($decoded_data) ) {
                $product_data = $decoded_data;
                set_transient( $transient_key_prod, $product_data, HOUR_IN_SECONDS );
            } else { $product_data = 'error_decode'; } // Ustaw flagę błędu
        } elseif (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 404) {
             $product_data = 'not_found'; // Ustaw flagę błędu
        } else {
             $product_data = 'error_fetch'; // Ustaw flagę błędu
        }
        // Zapisz flagę błędu w cache, jeśli wystąpił
        if (!is_array($product_data)) {
            set_transient($transient_key_prod, $product_data, MINUTE_IN_SECONDS * 5);
        }
    } // Koniec pobierania danych produktu

    // Jeśli dane produktu są niepoprawne lub wystąpił błąd w cache
    if ( !is_array($product_data) || empty($product_data['galeria_produktu']) || !is_array($product_data['galeria_produktu']) ) {
        // Możesz dodać logowanie błędu, jeśli $product_data nie jest tablicą i nie jest flagą 'not_found'
        if (is_string($product_data) && $product_data !== 'not_found') {
             error_log("[jbeauty_gallery] Invalid product data or error flag found in transient for CDT ID " . $cdt_id_value . ": " . $product_data);
        } elseif (!is_array($product_data)) {
             error_log("[jbeauty_gallery] Invalid product data found in transient for CDT ID " . $cdt_id_value);
        }
        return ''; // Zwróć pusty string, jeśli nie ma galerii lub wystąpił błąd
    }

    $image_ids = $product_data['galeria_produktu'];

    // --- Pobieranie danych mediów (z cache lub API) ---
    $media_cache_key = 'jbad_media_' . md5(implode(',', $image_ids));
    $media_data = get_transient($media_cache_key);

    if ( false === $media_data ) {
        // Zbuduj URL do endpointu mediów WP (na podstawie URL API Physis)
        $parsed_url = wp_parse_url($api_base_url);
        $media_api_host = ($parsed_url['scheme'] ?? 'https') . '://' . ($parsed_url['host'] ?? '');
        if (!empty($parsed_url['port'])) { $media_api_host .= ':' . $parsed_url['port']; }
        $media_api_url = $media_api_host . '/wp-json/wp/v2/media';

        // Przygotuj argumenty zapytania o media
        $media_query_args = array(
            'include'  => implode(',', $image_ids),
            'per_page' => count($image_ids),
            '_fields'  => 'id,source_url,alt_text,media_details' // Pobierz tylko potrzebne pola
        );
        $media_api_url_full = add_query_arg( $media_query_args, $media_api_url );

        $media_args = array( 'headers' => array( 'Authorization' => 'Bearer ' . $api_key ), 'timeout' => 20 );
        $media_response = wp_remote_get( $media_api_url_full, $media_args );
        $media_data = null; // Resetuj

        if ( !is_wp_error($media_response) && wp_remote_retrieve_response_code($media_response) === 200 ) {
            $decoded_media = json_decode( wp_remote_retrieve_body( $media_response ), true );
            if ( is_array( $decoded_media ) ) {
                // Stwórz mapę danych mediów [id => dane] dla łatwiejszego dostępu
                $media_data_map = array();
                foreach ($decoded_media as $media_item) {
                    if (isset($media_item['id'])) {
                        $media_data_map[$media_item['id']] = $media_item;
                    }
                }
                $media_data = $media_data_map;
                set_transient( $media_cache_key, $media_data, HOUR_IN_SECONDS ); // Cache na godzinę
            } else {
                $media_data = 'error_decode_media'; // Flaga błędu
            }
        } else {
             $media_data = 'error_fetch_media'; // Flaga błędu
        }
        // Zapisz flagę błędu mediów w cache
        if (!is_array($media_data)) {
            set_transient($media_cache_key, $media_data, MINUTE_IN_SECONDS * 5);
        }
    } // Koniec pobierania danych mediów

    // Jeśli dane mediów są niepoprawne lub wystąpił błąd w cache
    if ( empty($media_data) || !is_array($media_data) ) {
         error_log("[jbeauty_gallery] Invalid media data or error flag found in transient for CDT ID " . $cdt_id_value);
        return '';
    }

    // --- Generowanie HTML Galerii ---
    $unique_gallery_id = 'jbg-' . esc_attr($cdt_id_value) . '-' . wp_rand(100,999); // Dodaj losowość dla pewności unikalności na stronie
    $output = '<div class="jbeauty-gallery-wrapper ' . $unique_gallery_id . '">';

    // Główny Swiper
    $output .= '<div style="--swiper-navigation-color: #333; --swiper-pagination-color: #333" class="swiper jbeauty-main-swiper">';
    $output .= '<div class="swiper-wrapper">';
    foreach ( $image_ids as $image_id ) {
        if ( isset( $media_data[$image_id] ) ) {
            $media_item = $media_data[$image_id];
            $full_url = $media_item['source_url'] ?? '';
            // Użyj 'large' jeśli istnieje, inaczej pełny rozmiar
            $large_url = $media_item['media_details']['sizes']['large']['source_url'] ?? $full_url;
            $alt_text = !empty($media_item['alt_text']) ? esc_attr($media_item['alt_text']) : (isset($product_data['title']['rendered']) ? esc_attr($product_data['title']['rendered']) : '');
            if (!empty($full_url) && !empty($large_url)) {
                 // Dodaj atrybut data-src dla optymalizacji (opcjonalne, jeśli Fancybox/Swiper to obsługują)
                $output .= '<div class="swiper-slide">';
                $output .= '<a data-fancybox="' . $unique_gallery_id . '" href="' . esc_url($full_url) . '" data-caption="' . $alt_text . '">';
                $output .= '<img src="' . esc_url($large_url) . '" alt="' . $alt_text . '" loading="lazy" />';
                $output .= '</a></div>';
            }
        }
    }
    $output .= '</div>';
    // Przyciski nawigacji (jeśli więcej niż 1 slajd)
    if (count($image_ids) > 1) {
        $output .= '<div class="swiper-button-next"></div>';
        $output .= '<div class="swiper-button-prev"></div>';
    }
    $output .= '</div>'; // Koniec jbeauty-main-swiper

    // Swiper z miniaturkami (jeśli więcej niż 1 slajd)
    if (count($image_ids) > 1) {
        $output .= '<div thumbsSlider="" class="swiper jbeauty-thumbs-swiper">';
        $output .= '<div class="swiper-wrapper">';
        foreach ( $image_ids as $image_id ) {
            if ( isset( $media_data[$image_id] ) ) {
                $media_item = $media_data[$image_id];
                // Użyj 'thumbnail' jeśli istnieje, inaczej 'medium', inaczej pełny
                 $thumb_url = $media_item['media_details']['sizes']['thumbnail']['source_url']
                           ?? ($media_item['media_details']['sizes']['medium']['source_url']
                           ?? $media_item['source_url']);
                $alt_text = !empty($media_item['alt_text']) ? esc_attr($media_item['alt_text']) : (isset($product_data['title']['rendered']) ? esc_attr($product_data['title']['rendered']) : '');
                if (!empty($thumb_url)) {
                    $output .= '<div class="swiper-slide"><img src="' . esc_url($thumb_url) . '" alt="' . $alt_text . '" loading="lazy" /></div>';
                }
            }
        }
        $output .= '</div>'; // Koniec swiper-wrapper (thumbs)
        $output .= '</div>'; // Koniec jbeauty-thumbs-swiper
    } // Koniec if (count($image_ids) > 1)

    $output .= '</div>'; // Koniec jbeauty-gallery-wrapper

    return $output;
}
// Użyj warunku, aby uniknąć błędu przy wielokrotnym dołączaniu (chociaż nie powinno się zdarzyć)
if (!shortcode_exists('jbeauty_gallery')) {
    add_shortcode( 'jbeauty_gallery', 'physis_display_jbeauty_gallery_shortcode' );
}

// =============================================================================
// === ŁADOWANIE STYLÓW I SKRYPTÓW DLA GALERII (SWIPER + FANCYBOX) ===
// =============================================================================
function physis_enqueue_gallery_assets() {
    global $post;
    // Sprawdź, czy $post jest obiektem i czy ma właściwość post_content
     // oraz czy shortcode istnieje w treści
    if ( ! is_admin() && is_a( $post, 'WP_Post' ) && !empty($post->post_content) && has_shortcode( $post->post_content, 'jbeauty_gallery' ) ) {

        wp_enqueue_style( 'swiper-css', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css', array(), '11.0.5' ); // Wersja z dokumentacji
        wp_enqueue_script( 'swiper-js', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js', array(), '11.0.5', true );

        wp_enqueue_style( 'fancybox-css', 'https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.css', array(), '5.0.36' ); // Wersja z dokumentacji
        wp_enqueue_script( 'fancybox-js', 'https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.umd.js', array(), '5.0.36', true );

        // Skrypt inicjalizujący
        // Użyj wp_add_inline_script dla lepszej praktyki niż tag <script> w treści
        // Użyj heredoc dla czytelności
        $inline_script = <<<JS
        document.addEventListener('DOMContentLoaded', function() {
            const galleryWrappers = document.querySelectorAll('.jbeauty-gallery-wrapper[class*="jbg-"]');
            galleryWrappers.forEach(wrapper => {
                const mainSwiperEl = wrapper.querySelector('.jbeauty-main-swiper');
                const thumbsSwiperEl = wrapper.querySelector('.jbeauty-thumbs-swiper');
                const nextEl = wrapper.querySelector('.swiper-button-next');
                const prevEl = wrapper.querySelector('.swiper-button-prev');
                // Usunięto galleryId, nie jest używane w tym JS
                let thumbsSwiper = null;

                // Inicjalizuj Swiper dla miniaturek, jeśli istnieje
                if (thumbsSwiperEl) {
                    thumbsSwiper = new Swiper(thumbsSwiperEl, {
                        spaceBetween: 10,          // Mniejszy odstęp dla miniaturek
                        slidesPerView: 'auto',     // Dostosuj liczbę widocznych miniaturek
                        freeMode: true,
                        watchSlidesProgress: true,
                        // centeredSlides: false,  // Wykomentowane, może niepotrzebne przy slidesPerView:'auto'
                        slideToClickedSlide: true,
                    });
                }

                // Inicjalizuj główny Swiper, jeśli istnieje
                if (mainSwiperEl) {
                    const mainSwiperConfig = {
                        spaceBetween: 10,
                        loop: true, // Zapętlanie
                        navigation: {
                            nextEl: nextEl,
                            prevEl: prevEl,
                        }
                    };
                    // Połącz z miniaturkami tylko jeśli thumbsSwiper został zainicjalizowany
                    if (thumbsSwiper) {
                         mainSwiperConfig.thumbs = {
                             swiper: thumbsSwiper
                         };
                    }
                    const mainSwiper = new Swiper(mainSwiperEl, mainSwiperConfig);
                }
            }); // Koniec forEach

            // Inicjalizuj Fancybox dla wszystkich galerii na stronie
             Fancybox.bind('[data-fancybox^="jbg-"]', {
                // Opcje Fancybox
                 Toolbar: {
                     display: {
                         left: ["infobar"],
                         middle: [], // Puste środkowe przyciski
                         right: ["slideshow", "thumbs", "close"],
                     }
                 },
                 Thumbs: {
                     type: "classic" // Lub "modern"
                 }
             });
        }); // Koniec DOMContentLoaded
JS;
        wp_add_inline_script( 'fancybox-js', $inline_script ); // Dodaj skrypt inline po fancybox-js
    }
}
add_action( 'wp_enqueue_scripts', 'physis_enqueue_gallery_assets' );

// Celowo brak zamykającego ?>